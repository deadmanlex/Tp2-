TP2

-- TO DO:

- Sex in Register
- Bookmarks (HomeController) filtering and view
- Check validation on forms (Admin - Users, Admin - Categories, Bookmarks)
- Tests 
