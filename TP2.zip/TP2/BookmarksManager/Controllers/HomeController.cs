﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BookmarksManager.Models;

namespace BookmarksManager.Controllers
{
    [UserAccess]
    public class HomeController : Controller
    {
        private DatabaseEntities db = new DatabaseEntities();

        // GET: Home
        public ActionResult Index()
        {
            var bookmarks = db.Bookmarks.Include(b => b.Category).Include(b => b.User);
            return View(bookmarks.ToList());
        }

        // GET: Home/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bookmark bookmark = db.Bookmarks.Find(id);
            if (bookmark == null)
            {
                return HttpNotFound();
            }
            return View(bookmark);
        }

        // GET: Home/Create
        public ActionResult Create()
        {
            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name");
            ViewBag.UserId = new SelectList(db.Users, "Id", "UserName");
            return View();
        }

        private void InitSessionSortAndFilter()
        {
            if (Session["ContactSortBy"] == null)
            {
                Session["ContactSortBy"] = "Name";
                Session["ContactSortAscendant"] = true;
            }

            if (Session["ContactFilterBySex"] == null)
            {
                Session["ContactFilterBySex"] = -1;
            }
        }
        public ActionResult Sort(string by)
        {
            if (by == (string)Session["ContactSortBy"])
                Session["ContactSortAscendant"] = !(bool)Session["ContactSortAscendant"];
            else
                Session["ContactSortAscendant"] = true;

            Session["ContactSortBy"] = by;
            return RedirectToAction("Index", "Contacts");
        }
        public ActionResult FilterBySex(int sex)
        {
            Session["ContactFilterBySex"] = sex;
            return RedirectToAction("Index", "Contacts");
        }

        // POST: Home/Create
        // Afin de déjouer les attaques par sur-validation, activez les propriétés spécifiques que vous voulez lier. Pour 
        // plus de détails, voir  https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,Url,UserId,Shared,CategoryId")] Bookmark bookmark)
        {
            if (ModelState.IsValid)
            {
                db.Bookmarks.Add(bookmark);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name", bookmark.CategoryId);
            ViewBag.UserId = new SelectList(db.Users, "Id", "UserName", bookmark.UserId);
            return View(bookmark);
        }

        // GET: Home/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bookmark bookmark = db.Bookmarks.Find(id);
            if (bookmark == null)
            {
                return HttpNotFound();
            }
            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name", bookmark.CategoryId);
            ViewBag.UserId = new SelectList(db.Users, "Id", "UserName", bookmark.UserId);
            return View(bookmark);
        }

        // POST: Home/Edit/5
        // Afin de déjouer les attaques par sur-validation, activez les propriétés spécifiques que vous voulez lier. Pour 
        // plus de détails, voir  https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Url,UserId,Shared,CategoryId")] Bookmark bookmark)
        {
            if (ModelState.IsValid)
            {
                db.Entry(bookmark).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name", bookmark.CategoryId);
            ViewBag.UserId = new SelectList(db.Users, "Id", "UserName", bookmark.UserId);
            return View(bookmark);
        }

        // GET: Home/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bookmark bookmark = db.Bookmarks.Find(id);
            if (bookmark == null)
            {
                return HttpNotFound();
            }
            return View(bookmark);
        }

        // POST: Home/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Bookmark bookmark = db.Bookmarks.Find(id);
            db.Bookmarks.Remove(bookmark);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
