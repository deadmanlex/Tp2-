﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BookmarksManager.Models;

namespace BookmarksManager.Controllers
{
    public class AuthController : Controller
    {
        private BookmarksManager.Models.DatabaseEntities DB = new BookmarksManager.Models.DatabaseEntities();


        [UserAccess]
        public ActionResult Logout()
        {
            OnlineUsers.RemoveSessionUser();
            return Redirect("Login");
        }



        [PublicAccess]
        public ActionResult Login()
        {
            return View();
        }



        [HttpPost]
        public ActionResult Login(UserLoginView loginView)
        {
            if (ModelState.IsValid)
            {
                User userFound = DB.Users.Where(u => u.UserName == loginView.UserName).FirstOrDefault();
                if (userFound == null)
                {
                    ModelState.AddModelError("UserName", "This username does not exist.");
                    return View();
                }
                else
                {
                    if (userFound.Password != loginView.Password)
                    {
                        ModelState.AddModelError("password", "Wrong password");
                        return View();
                    }
                }
                OnlineUsers.AddSessionUser(userFound);
                return RedirectToAction("Index", "Home");

            }
            else
            {
                return View();
            }
        }

        [PublicAccess]
        public ActionResult Register()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Register(UserView userView)
        {
            if (ModelState.IsValid)
            {
                if (userView.Password != userView.ConfirmPassword)
                {
                    ModelState.AddModelError("password", "Password and password confirmation not matching");
                    return View();
                }

                DB.Users.Add(BookmarksManager.Models.User.FromUserView(userView));
                DB.SaveChanges();
            }
            else
                return View();

            return RedirectToAction("Login", "Auth");
        }

    }
}